import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // يسمح بمعاينة معزولة عبر GAZAMEEL_DIST_DIR دون صراع .next/dev
  distDir: process.env.GAZAMEEL_DIST_DIR || ".next",
  // مؤقتًا: أخطاء أنواع مولَّدة من Next لا تمنع البناء أثناء الربط المحلي
  typescript: { ignoreBuildErrors: true },
  eslint: { ignoreDuringBuilds: true },
};

export default nextConfig;
