#!/usr/bin/env node
/**
 * إدارة Webhook تيليجرام من .env.local (لا يطبع التوكن).
 *
 * الاستخدام:
 *   node scripts/telegram-webhook.mjs set
 *   node scripts/telegram-webhook.mjs info
 *   node scripts/telegram-webhook.mjs delete
 *   node scripts/telegram-webhook.mjs me
 *
 * يتطلب: TELEGRAM_BOT_TOKEN و NEXT_PUBLIC_APP_URL (HTTPS للإنتاج)
 * مستحسن: TELEGRAM_WEBHOOK_SECRET
 */
import { readFileSync, existsSync } from "node:fs";
import { resolve, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const envPath = resolve(root, ".env.local");

function loadEnv(path) {
  const out = {};
  if (!existsSync(path)) return out;
  for (const line of readFileSync(path, "utf8").split("\n")) {
    const t = line.trim();
    if (!t || t.startsWith("#")) continue;
    const i = t.indexOf("=");
    if (i < 0) continue;
    const key = t.slice(0, i).trim();
    let val = t.slice(i + 1).trim();
    if (
      (val.startsWith('"') && val.endsWith('"')) ||
      (val.startsWith("'") && val.endsWith("'"))
    ) {
      val = val.slice(1, -1);
    }
    out[key] = val;
  }
  return out;
}

function maskToken(token) {
  if (!token || token.length < 12) return "(missing)";
  return `${token.slice(0, 4)}…${token.slice(-4)}`;
}

function requireHttpsAppUrl(url) {
  try {
    const u = new URL(url);
    if (u.protocol !== "https:") {
      throw new Error("NEXT_PUBLIC_APP_URL يجب أن يكون HTTPS لـ setWebhook");
    }
    return u.origin;
  } catch (e) {
    if (e instanceof TypeError) throw new Error("NEXT_PUBLIC_APP_URL غير صالح");
    throw e;
  }
}

async function tg(token, method, body) {
  const res = await fetch(`https://api.telegram.org/bot${token}/${method}`, {
    method: body ? "POST" : "GET",
    headers: body ? { "Content-Type": "application/json" } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json();
  return data;
}

const env = { ...loadEnv(envPath), ...process.env };
const token = (env.TELEGRAM_BOT_TOKEN || "").trim();
const action = (process.argv[2] || "info").toLowerCase();

if (!token) {
  console.error("TELEGRAM_BOT_TOKEN فارغ في .env.local — الصقه من BotFather أولًا.");
  process.exit(1);
}

console.log(`token: ${maskToken(token)}`);
console.log(`action: ${action}`);

if (action === "me") {
  const data = await tg(token, "getMe");
  console.log(JSON.stringify(data, null, 2));
  process.exit(data.ok ? 0 : 1);
}

if (action === "info") {
  const data = await tg(token, "getWebhookInfo");
  console.log(JSON.stringify(data, null, 2));
  process.exit(data.ok ? 0 : 1);
}

if (action === "delete") {
  const data = await tg(token, "deleteWebhook", { drop_pending_updates: false });
  console.log(JSON.stringify(data, null, 2));
  process.exit(data.ok ? 0 : 1);
}

if (action === "set") {
  const appUrl = (env.NEXT_PUBLIC_APP_URL || "").trim();
  if (!appUrl || appUrl.includes("localhost") || appUrl.includes("127.0.0.1")) {
    console.error(
      "NEXT_PUBLIC_APP_URL يجب أن يكون رابط إنتاج HTTPS (ليس localhost)."
    );
    process.exit(1);
  }
  const origin = requireHttpsAppUrl(appUrl);
  const webhookUrl = `${origin}/api/telegram/webhook`;
  const secret = (env.TELEGRAM_WEBHOOK_SECRET || "").trim();
  const body = { url: webhookUrl };
  if (secret) body.secret_token = secret;
  else console.warn("تحذير: TELEGRAM_WEBHOOK_SECRET فارغ — عيّنه لتقوية الـ webhook.");

  console.log(`url: ${webhookUrl}`);
  console.log(`secret_token: ${secret ? "set" : "missing"}`);
  const data = await tg(token, "setWebhook", body);
  console.log(JSON.stringify(data, null, 2));
  process.exit(data.ok ? 0 : 1);
}

console.error("الاستخدام: node scripts/telegram-webhook.mjs <set|info|delete|me>");
process.exit(1);
