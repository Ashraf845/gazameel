-- ============================================================
-- Gazameel — مخطط قاعدة البيانات (مرحلة 1 + جداول لاحقة)
-- نفّذ هذا الملف أولًا في: Supabase → SQL Editor → New query → Run
-- ثم نفّذ: supabase/rls.sql
-- ============================================================
--
-- Storage (مهم — من الواجهة وليس من SQL):
--   1) Storage → New bucket
--   2) Name: resources
--   3) Public bucket: OFF (Private)
--   4) File size limit: 15MB (اختياري)
--   5) Allowed MIME: application/pdf, image/jpeg, image/png, image/webp
-- مسارات الملفات داخل الـ bucket:
--   pending/{user_id}/{uuid}.ext   ← مساهمات بانتظار المراجعة
--   approved/{course_id}/{uuid}.ext ← رفع أدمن مباشر / ملفات معتمدة
-- لا تضع روابط عامة دائمة لملفات pending — التطبيق يستخدم Signed URL.
--
-- ============================================================

create extension if not exists "pgcrypto";

-- ------------------------------------------------------------
-- المواد الدراسية (قائمة فصل دراسي واحد في الإطلاق)
-- semester_key: معرّف الفصل — مثال level2-sem1 = المستوى 2 فصل 1
-- ------------------------------------------------------------
create table if not exists public.courses (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  name_ar text not null,
  name_en text,
  -- university=جامعة | college=كلية | major=تخصص
  course_type text,
  -- مفتاح الفصل الدراسي (للتصفية لاحقًا إن أضفت فصولًا أخرى)
  semester_key text not null default 'level2-sem1',
  semester_label_ar text not null default 'المستوى الثاني — الفصل الأول',
  credit_hours int,
  created_at timestamptz default now()
);

alter table public.courses add column if not exists course_type text;
alter table public.courses add column if not exists semester_key text;
alter table public.courses add column if not exists semester_label_ar text;
alter table public.courses add column if not exists credit_hours int;

update public.courses
set
  semester_key = coalesce(semester_key, 'level2-sem1'),
  semester_label_ar = coalesce(semester_label_ar, 'المستوى الثاني — الفصل الأول')
where semester_key is null or semester_label_ar is null;

do $$ begin
  alter table public.courses
    alter column semester_key set default 'level2-sem1';
  alter table public.courses
    alter column semester_label_ar set default 'المستوى الثاني — الفصل الأول';
exception when others then null;
end $$;

do $$ begin
  alter table public.courses
    add constraint courses_course_type_check
    check (course_type in ('university', 'college', 'major'));
exception
  when duplicate_object then null;
end $$;

-- ------------------------------------------------------------
-- ملفات الطلاب (profiles) — تُنشأ تلقائيًا عند تسجيل Google
-- ------------------------------------------------------------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  email text,
  student_id text,
  major text,
  is_admin boolean default false,
  onboarding_done boolean default false,
  telegram_chat_id text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- مواد يختارها الطالب في onboarding
create table if not exists public.student_courses (
  user_id uuid references public.profiles(id) on delete cascade,
  course_id uuid references public.courses(id) on delete cascade,
  primary key (user_id, course_id)
);

-- ------------------------------------------------------------
-- الموارد (ملفات المكتبة) — pending → approved | rejected
-- ------------------------------------------------------------
create table if not exists public.resources (
  id uuid primary key default gen_random_uuid(),
  course_id uuid not null references public.courses(id),
  title text not null,
  description text,
  resource_type text not null default 'summary'
    check (resource_type in ('summary', 'past_exam', 'video', 'image', 'other')),
  storage_path text,
  mime_type text,
  file_size bigint,
  external_url text,
  status text not null default 'pending'
    check (status in ('pending', 'approved', 'rejected')),
  contributor_display_name text,
  uploaded_by uuid references public.profiles(id),
  rejection_reason text,
  source_note text,
  created_at timestamptz default now(),
  reviewed_at timestamptz,
  reviewed_by uuid references public.profiles(id)
);

-- آخر التحديثات (الصفحة الرئيسية)
create table if not exists public.updates_feed (
  id uuid primary key default gen_random_uuid(),
  message text not null,
  resource_id uuid references public.resources(id) on delete set null,
  created_at timestamptz default now()
);

-- تقويم الامتحانات
create table if not exists public.exam_events (
  id uuid primary key default gen_random_uuid(),
  course_id uuid not null references public.courses(id),
  title text not null,
  event_type text not null check (event_type in ('quiz', 'midterm', 'final', 'assignment')),
  starts_at timestamptz not null,
  notes text,
  created_by uuid references public.profiles(id),
  created_at timestamptz default now()
);

-- ------------------------------------------------------------
-- جداول مراحل لاحقة (آمنة للتنفيذ الآن — لا تؤذي المرحلة 1)
-- ------------------------------------------------------------
create table if not exists public.questions (
  id uuid primary key default gen_random_uuid(),
  course_id uuid not null references public.courses(id),
  topic text,
  question text not null,
  option_a text not null,
  option_b text not null,
  option_c text not null,
  option_d text not null,
  correct text not null check (correct in ('A', 'B', 'C', 'D')),
  explanation text,
  active boolean default true,
  daily_eligible boolean default false,
  created_at timestamptz default now()
);

create table if not exists public.quiz_attempts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  course_id uuid not null references public.courses(id),
  score int not null,
  total int not null,
  answers jsonb not null default '[]',
  created_at timestamptz default now()
);

create table if not exists public.polls (
  id uuid primary key default gen_random_uuid(),
  course_id uuid references public.courses(id),
  question text not null,
  options jsonb not null,
  active boolean default true,
  created_by uuid references public.profiles(id),
  created_at timestamptz default now()
);

create table if not exists public.poll_votes (
  poll_id uuid references public.polls(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete cascade,
  option_index int not null,
  created_at timestamptz default now(),
  primary key (poll_id, user_id)
);

create table if not exists public.reminder_log (
  id uuid primary key default gen_random_uuid(),
  exam_event_id uuid not null references public.exam_events(id) on delete cascade,
  window_label text not null,
  sent_at timestamptz default now(),
  unique (exam_event_id, window_label)
);

-- ------------------------------------------------------------
-- بذرة مواد الفصل: المستوى الثاني — الفصل الأول (18 ساعة)
-- ------------------------------------------------------------
insert into public.courses (code, name_ar, name_en, course_type, semester_key, semester_label_ar, credit_hours) values
  ('ARAB1202', 'اللغة العربية (نحو وصرف)', 'Arabic Language (Grammar and Morphology)', 'university', 'level2-sem1', 'المستوى الثاني — الفصل الأول', 2),
  ('ECOM2311', 'رياضيات متقطعة', 'Discrete Mathematics', 'major', 'level2-sem1', 'المستوى الثاني — الفصل الأول', 3),
  ('ECOM2402', 'برمجة حاسوب (2)', 'Computer Programming (2)', 'major', 'level2-sem1', 'المستوى الثاني — الفصل الأول', 4),
  ('ENGG1209', 'رسم هندسي بالحاسوب', 'Computer-Aided Engineering Drawing', 'college', 'level2-sem1', 'المستوى الثاني — الفصل الأول', 2),
  ('ENGG1305', 'لغة إنجليزية تقنية', 'Technical English', 'college', 'level2-sem1', 'المستوى الثاني — الفصل الأول', 3),
  ('MATH2341', 'جبر خطي', 'Linear Algebra', 'major', 'level2-sem1', 'المستوى الثاني — الفصل الأول', 3),
  ('QURN3101', 'قرآن كريم (3)', 'Holy Quran (3)', 'university', 'level2-sem1', 'المستوى الثاني — الفصل الأول', 1)
on conflict (code) do update set
  name_ar = excluded.name_ar,
  name_en = excluded.name_en,
  course_type = excluded.course_type,
  semester_key = excluded.semester_key,
  semester_label_ar = excluded.semester_label_ar,
  credit_hours = excluded.credit_hours;

-- إنشاء بروفايل تلقائي عند أول تسجيل Google
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, email, full_name)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name', '')
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- تفعيل RLS (السياسات التفصيلية في rls.sql)
alter table public.profiles enable row level security;
alter table public.student_courses enable row level security;
alter table public.courses enable row level security;
alter table public.resources enable row level security;
alter table public.updates_feed enable row level security;
alter table public.exam_events enable row level security;
alter table public.questions enable row level security;
alter table public.quiz_attempts enable row level security;
alter table public.polls enable row level security;
alter table public.poll_votes enable row level security;
alter table public.reminder_log enable row level security;

-- انتهى schema.sql — نفّذ الآن supabase/rls.sql
