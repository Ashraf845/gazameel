/**
 * شريط التنقل — روابط أساسية + قائمة المزيد + أدمن للمشرف فقط
 */
import Link from "next/link";
import { BRAND } from "@/shared/lib/constants";
import { AuthNav } from "@/shared/components/AuthNav";
import { getProfile } from "@/features/auth/auth";
import { SiteNav } from "@/shared/components/SiteNav";
import { ThemeToggle } from "@/shared/components/ThemeToggle";

export const dynamic = "force-dynamic";

export async function Navbar() {
  const profile = await getProfile();

  return (
    <header className="relative border-b border-white/10 bg-[#0b1f17]/90 backdrop-blur sticky top-0 z-50">
      <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-3">
        <Link href="/" className="text-lg font-bold tracking-wide text-[#7dcea0]">
          {BRAND}
        </Link>
        <SiteNav isAdmin={!!profile?.is_admin} />
        <div className="flex items-center gap-1">
          <ThemeToggle />
          <AuthNav />
        </div>
      </div>
    </header>
  );
}
