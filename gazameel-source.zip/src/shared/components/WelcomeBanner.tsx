import Link from "next/link";
import { getProfile, getSessionUser } from "@/features/auth/auth";
import { getAvatarUrl, getDisplayName } from "@/features/auth/user-display";

export async function WelcomeBanner() {
  const user = await getSessionUser();
  if (!user) return null;

  const profile = await getProfile();
  const name = getDisplayName(user, profile);
  const avatar = getAvatarUrl(user);
  const onboardingDone = profile?.onboarding_done;

  return (
    <div className="mx-auto max-w-6xl px-4 pt-4">
      <div className="card-soft flex flex-wrap items-center gap-4 p-4 md:p-5">
        {avatar ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={avatar}
            alt=""
            width={56}
            height={56}
            className="h-14 w-14 rounded-full object-cover ring-2 ring-[#7dcea0]/50"
            referrerPolicy="no-referrer"
          />
        ) : (
          <span className="flex h-14 w-14 items-center justify-center rounded-full bg-[#2e8b57]/30 text-xl font-bold text-[#7dcea0]">
            {name.charAt(0).toUpperCase()}
          </span>
        )}
        <div className="min-w-0 flex-1">
          <p className="text-lg font-semibold text-white">
            مرحبًا، {name} 👋
          </p>
          <p className="text-sm text-white/65 mt-0.5">
            {onboardingDone
              ? "تم تسجيل دخولك — استكشف المكتبة أو ساهم بملخص."
              : "أكمل تسجيلك (رقم جامعي + مواد) للمتابعة."}
          </p>
        </div>
        <div className="flex flex-wrap gap-2 shrink-0">
          {!onboardingDone ? (
            <Link href="/onboarding" className="btn-primary text-sm">
              أكمل التسجيل
            </Link>
          ) : (
            <>
              <Link href="/hub" className="btn-primary text-sm">
                المكتبة
              </Link>
              <Link href="/quiz" className="btn-ghost text-sm">
                اختبر نفسك
              </Link>
              <Link href="/upload" className="btn-ghost text-sm">
                ساهم
              </Link>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
