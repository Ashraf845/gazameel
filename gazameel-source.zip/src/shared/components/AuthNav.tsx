"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { createClient } from "@/shared/lib/supabase/client";
import { getAvatarUrl, getDisplayName } from "@/features/auth/user-display";
import type { User } from "@supabase/supabase-js";

export function AuthNav() {
  const [user, setUser] = useState<User | null>(null);
  const [profileName, setProfileName] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    async function loadUser() {
      try {
        const supabase = createClient();
        if (!supabase) return;

        const { data: authData } = await supabase.auth.getUser();
        if (cancelled) return;

        const u = authData.user;
        setUser(u ?? null);

        if (u) {
          const { data: profile } = await supabase
            .from("profiles")
            .select("full_name")
            .eq("id", u.id)
            .maybeSingle();
          if (!cancelled) setProfileName(profile?.full_name ?? null);
        } else {
          setProfileName(null);
        }
      } catch {
        if (!cancelled) {
          setUser(null);
          setProfileName(null);
        }
      }
    }

    loadUser();

    const supabase = createClient();
    if (!supabase) return;

    const { data: sub } = supabase.auth.onAuthStateChange(() => {
      loadUser();
    });

    return () => {
      cancelled = true;
      sub.subscription.unsubscribe();
    };
  }, []);

  async function signOut() {
    try {
      await fetch("/api/auth/signout", { method: "POST" });
    } catch {
      /* ignore */
    }
    window.location.href = "/";
  }

  if (!user) {
    return (
      <Link href="/login" className="btn-ghost py-1 px-2 text-xs">
        دخول
      </Link>
    );
  }

  const name = getDisplayName(user, { full_name: profileName });
  const avatar = getAvatarUrl(user);

  return (
    <div className="flex items-center gap-2 mr-1">
      <div
        className="flex items-center gap-2 rounded-lg border border-white/10 bg-white/5 py-1 pl-2 pr-3"
        title={user.email ?? undefined}
      >
        {avatar ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={avatar}
            alt=""
            width={28}
            height={28}
            className="h-7 w-7 rounded-full object-cover ring-1 ring-[#7dcea0]/40"
            referrerPolicy="no-referrer"
          />
        ) : (
          <span className="flex h-7 w-7 items-center justify-center rounded-full bg-[#2e8b57]/40 text-xs font-bold text-[#7dcea0]">
            {name.charAt(0).toUpperCase()}
          </span>
        )}
        <span className="hidden text-xs text-white/85 sm:inline max-w-[120px] truncate">
          مرحبًا، {name}
        </span>
      </div>
      <button type="button" onClick={signOut} className="btn-ghost py-1 px-2 text-xs">
        خروج
      </button>
    </div>
  );
}
