/** حالة ودّية عند غياب إعدادات Supabase */
export function SupabaseSetupNotice({
  title,
  detail,
}: {
  title: string;
  detail?: string;
}) {
  return (
    <div className="mx-auto max-w-2xl px-4 py-12">
      <h1 className="text-3xl font-bold mb-2">{title}</h1>
      <p className="text-white/70 text-sm leading-relaxed mb-4">
        {detail ||
          "المنصة تعمل بمعاينة محلية، لكن اتصال قاعدة البيانات غير مُعدّ بعد."}
      </p>
      <ol className="mb-4 list-decimal space-y-2 pr-5 text-sm text-white/60 leading-relaxed">
        <li>
          انسخ{" "}
          <code className="text-[#7dcea0]">.env.example</code> إلى{" "}
          <code className="text-[#7dcea0]">.env.local</code> (موجود مسبقًا
          بـ placeholders).
        </li>
        <li>
          الصق من Supabase → Project Settings → API القيم:{" "}
          <code className="text-[#7dcea0]">NEXT_PUBLIC_SUPABASE_URL</code> و{" "}
          <code className="text-[#7dcea0]">NEXT_PUBLIC_SUPABASE_ANON_KEY</code>{" "}
          و{" "}
          <code className="text-[#7dcea0]">SUPABASE_SERVICE_ROLE_KEY</code>.
        </li>
        <li>
          نفّذ{" "}
          <code className="text-[#7dcea0]">supabase/schema.sql</code> ثم{" "}
          <code className="text-[#7dcea0]">supabase/rls.sql</code> وأنشئ bucket{" "}
          <code className="text-[#7dcea0]">resources</code> (Private).
        </li>
        <li>أعد تشغيل الخادم المحلي.</li>
      </ol>
      <p className="text-white/50 text-sm leading-relaxed">
        الشرح التفصيلي نقرًا بنقرة:{" "}
        <code className="text-[#7dcea0]">docs/درس-المرحلة-1.md</code>
      </p>
    </div>
  );
}

/** شريط خفيف أعلى الصفحة عند غياب الإعداد */
export function SupabaseSetupBanner() {
  return (
    <div className="border-b border-[#e8b86d]/30 bg-[#e8b86d]/10 px-4 py-3 text-center text-sm text-[#e8b86d]">
      معاينة بدون قاعدة بيانات — الصق مفاتيح Supabase في{" "}
      <code className="text-white/90">.env.local</code> واتبع{" "}
      <code className="text-white/90">docs/درس-المرحلة-1.md</code>
    </div>
  );
}
