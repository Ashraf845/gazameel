"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";

const PRIMARY = [
  { href: "/", label: "الرئيسية" },
  { href: "/hub", label: "المكتبة" },
  { href: "/quiz", label: "اختبارات" },
  { href: "/upload", label: "ساهم" },
  { href: "/calendar", label: "التقويم" },
];

const MORE = [
  { href: "/polls", label: "استطلاعات" },
  { href: "/progress", label: "تقدمي" },
  { href: "/my-submissions", label: "مساهماتي" },
  { href: "/contributors", label: "مساهمون" },
  { href: "/telegram", label: "تيليجرام" },
  { href: "/about", label: "عن المنصة" },
];

export function SiteNav({ isAdmin }: { isAdmin: boolean }) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);

  useEffect(() => {
    setOpen(false);
    setMoreOpen(false);
  }, [pathname]);

  const extra = isAdmin ? [{ href: "/admin", label: "أدمن" }] : [];
  const all = [...PRIMARY, ...extra, ...MORE];

  function active(href: string) {
    if (href === "/") return pathname === "/";
    return pathname === href || pathname.startsWith(`${href}/`);
  }

  return (
    <div className="flex items-center gap-1">
      <button
        type="button"
        className="rounded-md px-2 py-1 text-sm md:hidden hover:bg-white/10"
        aria-expanded={open}
        onClick={() => setOpen((v) => !v)}
      >
        القائمة
      </button>

      <nav className="hidden md:flex flex-wrap items-center gap-1 text-sm text-white/80">
        {PRIMARY.map((l) => (
          <Link
            key={l.href}
            href={l.href}
            className={`rounded-md px-2 py-1 hover:bg-white/10 hover:text-white ${
              active(l.href) ? "bg-white/10 text-white" : ""
            }`}
          >
            {l.label}
          </Link>
        ))}
        {extra.map((l) => (
          <Link
            key={l.href}
            href={l.href}
            className={`rounded-md px-2 py-1 hover:bg-white/10 hover:text-white ${
              active(l.href) ? "bg-white/10 text-white" : ""
            }`}
          >
            {l.label}
          </Link>
        ))}
        <div className="relative">
          <button
            type="button"
            className="rounded-md px-2 py-1 hover:bg-white/10"
            onClick={() => setMoreOpen((v) => !v)}
          >
            المزيد
          </button>
          {moreOpen && (
            <div className="absolute left-0 top-full z-50 mt-1 min-w-40 rounded-lg border border-white/10 bg-[#122a20] py-1 shadow-lg">
              {MORE.map((l) => (
                <Link
                  key={l.href}
                  href={l.href}
                  className="block px-3 py-2 text-sm hover:bg-white/10"
                >
                  {l.label}
                </Link>
              ))}
            </div>
          )}
        </div>
      </nav>

      {open && (
        <div className="absolute right-0 top-full z-50 w-full border-b border-white/10 bg-[#0b1f17] md:hidden">
          <nav className="mx-auto flex max-w-6xl flex-col gap-1 px-4 py-3 text-sm">
            {all.map((l) => (
              <Link
                key={l.href}
                href={l.href}
                className={`rounded-md px-2 py-2 hover:bg-white/10 ${
                  active(l.href) ? "bg-white/10" : ""
                }`}
              >
                {l.label}
              </Link>
            ))}
          </nav>
        </div>
      )}
    </div>
  );
}
