import { NextResponse } from "next/server";
import { createClient } from "@/shared/lib/supabase/server";

export async function POST() {
  const supabase = await createClient();
  if (supabase) {
    await supabase.auth.signOut();
  }
  return NextResponse.json({ ok: true });
}
