import { BRAND, DISCLAIMER_AR, TAGLINE_AR } from "@/shared/lib/constants";
import Link from "next/link";

function isRealUrl(val?: string | null) {
  if (!val?.trim()) return false;
  return !/YOUR_|placeholder|change-me|example/i.test(val);
}

export default function AboutPage() {
  const whatsapp = process.env.NEXT_PUBLIC_WHATSAPP_URL?.trim();
  const hasWhatsapp = isRealUrl(whatsapp);

  return (
    <div className="mx-auto max-w-2xl px-4 py-12 space-y-6">
      <h1 className="text-3xl font-bold">عن {BRAND}</h1>
      <p className="text-white/80 leading-relaxed">
        <strong>{BRAND}</strong> = Gaza + زميل. {TAGLINE_AR}
      </p>
      <p className="text-white/70 text-sm leading-relaxed">
        مبادرة فردية لطلاب كلية الهندسة وتكنولوجيا المعلومات — الجامعة الإسلامية.
        نجمع الملخصات، التقويم، والاختبارات، مع بوت تيليجرام للتذكير وموافقة المساهمات.
      </p>
      <div className="card-soft p-5 text-sm leading-relaxed text-white/80">
        <strong className="text-[#e8b86d]">تنويه مهم</strong>
        <p className="mt-2">{DISCLAIMER_AR}</p>
      </div>
      <div className="card-soft p-5 text-sm space-y-2">
        <h2 className="font-semibold text-[#7dcea0]">مجتمع واتساب</h2>
        <p className="text-white/70">
          للإعلانات السريعة والنقاش اليومي بين الطلاب (بدون أتمتة API في الـ MVP).
        </p>
        {hasWhatsapp ? (
          <a
            href={whatsapp}
            target="_blank"
            rel="noreferrer"
            className="btn-primary inline-block"
          >
            انضم لمجموعة واتساب
          </a>
        ) : (
          <p className="text-white/50 text-xs leading-relaxed">
            الرابط غير مضبوط بعد. ضع{" "}
            <code className="text-[#7dcea0]">NEXT_PUBLIC_WHATSAPP_URL</code> في{" "}
            <code>.env.local</code> — التفاصيل في{" "}
            <code>docs/درس-المرحلة-3.md</code> أو{" "}
            <code>docs/الربط-السريع.md</code>.
          </p>
        )}
      </div>
      <p className="text-sm flex flex-wrap gap-4">
        <Link href="/telegram" className="text-[#7dcea0] underline">
          ربط حساب تيليجرام للتذكيرات
        </Link>
        <Link href="/contributors" className="text-[#7dcea0] underline">
          المساهمون
        </Link>
      </p>
    </div>
  );
}
