import { getSessionUser } from "@/features/auth/auth";
import { redirect } from "next/navigation";
import { createClient } from "@/shared/lib/supabase/server";
import { SupabaseSetupNotice } from "@/shared/components/SupabaseSetupNotice";
import { isMissingOrPlaceholder } from "@/shared/lib/supabase/config";

export const dynamic = "force-dynamic";

export default async function TelegramLinkPage() {
  const supabase = await createClient();
  if (!supabase) {
    return <SupabaseSetupNotice title="ربط تيليجرام" />;
  }

  const user = await getSessionUser();
  if (!user) redirect("/login?next=/telegram");

  const botUsername = process.env.NEXT_PUBLIC_TELEGRAM_BOT_USERNAME?.trim();
  const botReady = !isMissingOrPlaceholder(botUsername);
  const deepLink = botReady
    ? `https://t.me/${botUsername}?start=link_${user.id}`
    : null;

  const { data: profile } = await supabase
    .from("profiles")
    .select("telegram_chat_id")
    .eq("id", user.id)
    .maybeSingle();

  return (
    <div className="mx-auto max-w-lg px-4 py-12 space-y-4">
      <h1 className="text-3xl font-bold">ربط تيليجرام</h1>
      <p className="text-white/70 text-sm leading-relaxed">
        اضغط الرابط لفتح البوت وإرسال /start — يُحفظ chat id عندك لاستقبال تذكيرات
        الامتحانات وسؤال اليوم.
      </p>
      {profile?.telegram_chat_id ? (
        <p className="text-[#7dcea0] text-sm">
          مرتبط حاليًا (chat: {profile.telegram_chat_id})
        </p>
      ) : (
        <p className="text-[#e8b86d] text-sm">غير مرتبط بعد</p>
      )}
      {deepLink ? (
        <a
          href={deepLink}
          target="_blank"
          rel="noreferrer"
          className="btn-primary inline-block"
        >
          افتح البوت واربط الحساب
        </a>
      ) : (
        <p className="text-sm text-[#e8b86d] leading-relaxed">
          البوت غير مضبوط بعد. ضع اسم المستخدم الحقيقي في{" "}
          <code className="text-white/80">NEXT_PUBLIC_TELEGRAM_BOT_USERNAME</code>{" "}
          داخل <code className="text-white/80">.env.local</code> (بدون @)، ثم أعد
          تشغيل الخادم. انظر{" "}
          <code className="text-white/80">docs/درس-المرحلة-2.md</code>.
        </p>
      )}
    </div>
  );
}
