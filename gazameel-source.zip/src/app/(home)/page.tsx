/**
 * الصفحة الرئيسية — هيرو + آخر التحديثات + اختصارات
 * التحديثات تُجلب من جدول updates_feed عند ربط Supabase.
 */
import Link from "next/link";
import { BRAND, TAGLINE_AR, TAGLINE_EN, DISCLAIMER_AR } from "@/shared/lib/constants";
import { createAdminClient } from "@/shared/lib/supabase/admin";
import { isSupabaseFullyConfigured } from "@/shared/lib/supabase/config";
import { UpdatesFeed } from "@/features/hub/components/UpdatesFeed";
import { SupabaseSetupBanner } from "@/shared/components/SupabaseSetupNotice";
import { WelcomeBanner } from "@/shared/components/WelcomeBanner";
import { getSessionUser } from "@/features/auth/auth";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const configured = isSupabaseFullyConfigured();
  const user = configured ? await getSessionUser() : null;
  let feed: { id: string; message: string; created_at: string }[] = [];

  if (configured) {
    try {
      const admin = createAdminClient();
      if (admin) {
        const { data } = await admin
          .from("updates_feed")
          .select("id, message, created_at")
          .order("created_at", { ascending: false })
          .limit(8);
        feed = data || [];
      }
    } catch {
      /* بدون اتصال فعلي — نعرض قائمة فارغة */
    }
  }

  return (
    <div>
      {!configured && <SupabaseSetupBanner />}
      {user && <WelcomeBanner />}

      {user && (
        <section className="mx-auto grid max-w-6xl gap-3 px-4 pt-6 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { href: "/hub", title: "المكتبة", body: "ملخصات وأسئلة سنوات معتمدة" },
            { href: "/quiz", title: "اختبار", body: "أسئلة اختيار من متعدد مع تصحيح" },
            { href: "/calendar", title: "التقويم", body: "مواعيد الكويز والمنتصف والنهائي" },
            { href: "/upload", title: "ساهم", body: "ارفع ملخصًا بانتظار موافقة الأدمن" },
          ].map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="card-soft block p-4 hover:border-[#7dcea0]/40 transition"
            >
              <h2 className="font-semibold text-[#7dcea0]">{item.title}</h2>
              <p className="mt-1 text-sm text-white/60">{item.body}</p>
            </Link>
          ))}
        </section>
      )}

      <section className="relative overflow-hidden border-b border-white/10">
        <div
          className="absolute inset-0 opacity-40"
          style={{
            backgroundImage:
              "linear-gradient(120deg, rgba(46,139,87,0.35), transparent 50%), url(\"data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%237dcea0' fill-opacity='0.08'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E\")",
          }}
        />
        <div className="relative mx-auto max-w-6xl px-4 py-20 md:py-28">
          <p className="mb-3 text-sm uppercase tracking-[0.2em] text-[#7dcea0]">
            {BRAND}
          </p>
          <h1 className="max-w-3xl text-4xl font-bold leading-tight md:text-6xl">
            {TAGLINE_AR}
          </h1>
          <p className="mt-4 max-w-xl text-lg text-white/70">{TAGLINE_EN}</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link href="/hub" className="btn-primary">
              ادخل المكتبة
            </Link>
            {!user && (
              <Link href="/login" className="btn-ghost">
                دخول Google
              </Link>
            )}
            <Link href="/upload" className="btn-ghost">
              ساهم بملخص
            </Link>
          </div>
        </div>
      </section>

      <section className="mx-auto grid max-w-6xl gap-6 px-4 py-12 md:grid-cols-3">
        <Feature
          title="مكتبة المواد"
          body="ملخصات وأسئلة سنوات معتمدة فقط تظهر بعد موافقة الأدمن."
          href="/hub"
        />
        <Feature
          title="رفع بمراجعة"
          body="ترفع → pending → موافقة من الويب أو تيليجرام."
          href="/upload"
        />
        <Feature
          title="اختبارات وتقويم"
          body="كويز فوري + مواعيد من مصدر واحد + تذكيرات بوت."
          href="/quiz"
        />
      </section>

      <section className="mx-auto max-w-6xl px-4 pb-10">
        <h2 className="text-xl font-semibold mb-4 text-[#7dcea0]">
          آخر التحديثات
        </h2>
        <UpdatesFeed items={feed} />
        {!configured && (
          <p className="mt-3 text-xs text-white/40">
            المصدر: جدول{" "}
            <code className="text-white/55">updates_feed</code> — يظهر بعد ربط
            Supabase واعتماد ملفات.
          </p>
        )}
      </section>

      <section className="mx-auto max-w-6xl px-4 pb-16">
        <div className="card-soft p-5 text-sm text-white/75 leading-relaxed">
          <strong className="text-[#e8b86d]">تنويه: </strong>
          {DISCLAIMER_AR}
        </div>
      </section>
    </div>
  );
}

function Feature({
  title,
  body,
  href,
}: {
  title: string;
  body: string;
  href: string;
}) {
  return (
    <Link
      href={href}
      className="card-soft block p-5 transition hover:border-[#7dcea0]/40"
    >
      <h2 className="mb-2 text-xl font-semibold text-[#7dcea0]">{title}</h2>
      <p className="text-sm text-white/70 leading-relaxed">{body}</p>
    </Link>
  );
}
