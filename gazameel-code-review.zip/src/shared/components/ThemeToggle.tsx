"use client";

/**
 * زر الوضع الليلي / الفاتح
 * المنصة dark-first؛ هذا للتبديل اليدوي عبر class على <html>
 */
import { useEffect, useState } from "react";

export function ThemeToggle() {
  const [light, setLight] = useState(false);

  useEffect(() => {
    setLight(localStorage.getItem("gazameel-theme") === "light");
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle("light-theme", light);
    localStorage.setItem("gazameel-theme", light ? "light" : "dark");
  }, [light]);

  return (
    <button
      type="button"
      onClick={() => setLight((v) => !v)}
      className="rounded px-2 py-1 text-xs text-[var(--text-secondary)] hover:text-[var(--accent-gold)]"
      title="تبديل المظهر"
    >
      {light ? "داكن" : "فاتح"}
    </button>
  );
}
