/**
 * تذييل الصفحة — يظهر التنويه غير الرسمي دائمًا + روابط المجتمع
 */
import { DISCLAIMER_AR, BRAND } from "@/shared/lib/constants";
import Link from "next/link";

export function Footer() {
  const whatsapp = process.env.NEXT_PUBLIC_WHATSAPP_URL?.trim();
  const hasWhatsapp =
    !!whatsapp &&
    !/YOUR_|placeholder|change-me/i.test(whatsapp);

  return (
    <footer className="mt-auto border-t border-[var(--border)] bg-[var(--bg-surface)] px-4 py-8 text-sm text-[var(--text-secondary)]">
      <div className="mx-auto max-w-6xl space-y-3">
        <p className="font-medium tracking-wide text-[var(--accent-gold)]">{BRAND}</p>
        <p className="leading-relaxed">{DISCLAIMER_AR}</p>
        <p className="flex flex-wrap gap-4">
          <Link
            href="/about"
            className="underline hover:text-[var(--text-primary)]"
          >
            اقرأ المزيد عن المنصة
          </Link>
          <Link
            href="/telegram"
            className="underline hover:text-[var(--text-primary)]"
          >
            ربط تيليجرام
          </Link>
          {hasWhatsapp ? (
            <a
              href={whatsapp}
              target="_blank"
              rel="noreferrer"
              className="underline hover:text-[var(--text-primary)]"
            >
              مجموعة واتساب
            </a>
          ) : null}
        </p>
      </div>
    </footer>
  );
}
