/**
 * الصفحة الرئيسية — quiet luxury: هيرو + سكة ميزات + تحديثات
 */
import Link from "next/link";
import { BRAND, TAGLINE_AR, TAGLINE_EN, DISCLAIMER_AR } from "@/shared/lib/constants";
import { createAdminClient } from "@/shared/lib/supabase/admin";
import { isSupabaseFullyConfigured } from "@/shared/lib/supabase/config";
import { UpdatesFeed } from "@/features/hub/components/UpdatesFeed";
import { SupabaseSetupBanner } from "@/shared/components/SupabaseSetupNotice";
import { WelcomeBanner } from "@/shared/components/WelcomeBanner";
import { getSessionUser } from "@/features/auth/auth";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const configured = isSupabaseFullyConfigured();
  const user = configured ? await getSessionUser() : null;
  let feed: { id: string; message: string; created_at: string }[] = [];

  if (configured) {
    try {
      const admin = createAdminClient();
      if (admin) {
        const { data } = await admin
          .from("updates_feed")
          .select("id, message, created_at")
          .order("created_at", { ascending: false })
          .limit(8);
        feed = data || [];
      }
    } catch {
      /* بدون اتصال فعلي — نعرض قائمة فارغة */
    }
  }

  return (
    <div>
      {!configured && <SupabaseSetupBanner />}
      {user && <WelcomeBanner />}

      {user && (
        <section className="mx-auto grid max-w-6xl gap-0 px-4 pt-6 sm:grid-cols-2 lg:grid-cols-4 feature-rail">
          {[
            { href: "/hub", title: "المكتبة", body: "ملخصات وأسئلة سنوات معتمدة" },
            { href: "/quiz", title: "اختبار", body: "أسئلة اختيار من متعدد مع تصحيح" },
            { href: "/calendar", title: "التقويم", body: "مواعيد الكويز والمنتصف والنهائي" },
            { href: "/upload", title: "ساهم", body: "ارفع ملخصًا بانتظار موافقة الأدمن" },
          ].map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="block p-4 transition hover:bg-[color-mix(in_srgb,var(--accent-gold)_6%,transparent)]"
            >
              <h2 className="font-semibold text-[var(--accent-gold)]">{item.title}</h2>
              <p className="mt-1 text-sm text-[var(--text-secondary)]">{item.body}</p>
            </Link>
          ))}
        </section>
      )}

      {/* Hero — نقشة زيتون خلف القسم فقط */}
      <section className="relative overflow-hidden border-b border-[var(--border)]">
        <div className="pointer-events-none absolute inset-0 hero-olive" aria-hidden>
          <svg
            width="100%"
            height="100%"
            viewBox="0 0 700 400"
            className="h-full w-full"
            preserveAspectRatio="xMidYMid slice"
          >
            <defs>
              <pattern
                id="olive"
                width="120"
                height="90"
                patternUnits="userSpaceOnUse"
              >
                <path
                  d="M10 60 Q35 30 60 45 Q85 60 110 35"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1"
                />
                <ellipse
                  cx="28"
                  cy="47"
                  rx="7"
                  ry="4"
                  fill="currentColor"
                  transform="rotate(-25 28 47)"
                />
                <ellipse
                  cx="48"
                  cy="38"
                  rx="7"
                  ry="4"
                  fill="currentColor"
                  transform="rotate(-10 48 38)"
                />
                <ellipse
                  cx="68"
                  cy="42"
                  rx="7"
                  ry="4"
                  fill="currentColor"
                  transform="rotate(15 68 42)"
                />
                <ellipse
                  cx="88"
                  cy="38"
                  rx="7"
                  ry="4"
                  fill="currentColor"
                  transform="rotate(-15 88 38)"
                />
              </pattern>
            </defs>
            <rect width="700" height="400" fill="url(#olive)" />
          </svg>
        </div>

        <div className="relative mx-auto max-w-6xl px-4 py-20 md:py-28">
          <div className="brand-rule mb-4" />
          <p className="mb-3 text-sm font-medium uppercase tracking-[0.28em] text-[var(--accent-gold)]">
            {BRAND}
          </p>
          <h1 className="max-w-3xl text-4xl font-bold leading-tight text-[var(--text-primary)] md:text-6xl">
            {TAGLINE_AR}
          </h1>
          <p className="mt-4 max-w-xl text-lg text-[var(--text-secondary)]">
            {TAGLINE_EN}
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <Link href="/hub" className="cta-button">
              ادخل المكتبة
            </Link>
            {!user && (
              <Link href="/login" className="btn-ghost">
                دخول Google
              </Link>
            )}
            <Link href="/upload" className="btn-ghost">
              ساهم بملخص
            </Link>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-12">
        <div className="feature-rail grid md:grid-cols-3">
          <Feature
            title="اختبارات"
            body="كويز فوري مع تصحيح فوري وتتبع تقدّمك."
            href="/quiz"
            icon="quiz"
          />
          <Feature
            title="مراجعة"
            body="ارفع ملخصًا → قيد المراجعة → موافقة من الويب أو تيليجرام."
            href="/upload"
            icon="upload"
          />
          <Feature
            title="مكتبة"
            body="ملخصات وأسئلة سنوات معتمدة فقط تظهر بعد موافقة الأدمن."
            href="/hub"
            icon="library"
          />
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 pb-10">
        <h2 className="mb-4 text-xl font-semibold text-[var(--accent-gold)]">
          آخر التحديثات
        </h2>
        <UpdatesFeed items={feed} />
        {!configured && (
          <p className="mt-3 text-xs text-[var(--text-secondary)]">
            المصدر: جدول{" "}
            <code className="text-[var(--text-primary)]">updates_feed</code> — يظهر
            بعد ربط Supabase واعتماد ملفات.
          </p>
        )}
      </section>

      <section className="mx-auto max-w-6xl px-4 pb-16">
        <div className="card-soft p-5 text-sm leading-relaxed text-[var(--text-secondary)]">
          <strong className="text-[var(--accent-gold)]">تنويه: </strong>
          {DISCLAIMER_AR}
        </div>
      </section>
    </div>
  );
}

function FeatureIcon({ name }: { name: "quiz" | "upload" | "library" }) {
  const common = {
    width: 22,
    height: 22,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.5,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    className: "text-[var(--accent-gold)]",
    "aria-hidden": true as const,
  };

  if (name === "quiz") {
    return (
      <svg {...common}>
        <path d="M9 5h-2a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-12a2 2 0 0 0-2-2h-2" />
        <path d="M9 5a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v0a2 2 0 0 1-2 2h-2a2 2 0 0 1-2-2z" />
        <path d="M9 12h.01M13 12h2M9 16h.01M13 16h2" />
      </svg>
    );
  }
  if (name === "upload") {
    return (
      <svg {...common}>
        <path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2" />
        <path d="M7 9l5-5l5 5" />
        <path d="M12 4v12" />
      </svg>
    );
  }
  return (
    <svg {...common}>
      <path d="M5 4h6a2 2 0 0 1 2 2v14a1 1 0 0 0-1-1h-7a2 2 0 0 1-2-2v-13a2 2 0 0 1 2-2" />
      <path d="M19 4h-6a2 2 0 0 0-2 2v14a1 1 0 0 1 1-1h7a2 2 0 0 0 2-2v-13a2 2 0 0 0-2-2" />
    </svg>
  );
}

function Feature({
  title,
  body,
  href,
  icon,
}: {
  title: string;
  body: string;
  href: string;
  icon: "quiz" | "upload" | "library";
}) {
  return (
    <Link
      href={href}
      className="block p-6 transition hover:bg-[color-mix(in_srgb,var(--accent-gold)_5%,transparent)]"
    >
      <FeatureIcon name={icon} />
      <h2 className="mt-3 mb-2 text-xl font-semibold text-[var(--text-primary)]">
        {title}
      </h2>
      <p className="text-sm leading-relaxed text-[var(--text-secondary)]">{body}</p>
    </Link>
  );
}
